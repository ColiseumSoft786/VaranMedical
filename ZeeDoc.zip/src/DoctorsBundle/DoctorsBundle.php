<?php

namespace DoctorsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class DoctorsBundle extends Bundle
{
}

<?php

namespace AppointmentsBundle;

use Symfony\Component\HttpKernel\Bundle\Bundle;

class AppointmentsBundle extends Bundle
{
}
